import { Component, OnInit } from '@angular/core';
import { ajax } from 'rxjs/ajax';
import { map, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-world-map',
  templateUrl: './world-map.component.html',
  styleUrls: ['./world-map.component.css']
})
export class WorldMapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  handleCountryClick(event) {

  	let iso3CountryCode = event.target.parentElement.className.baseVal.split(" ")[1];
  	iso2CountryCode = this.getIso2FromIso3(iso3CountryCode)
  }

  getIso2FromIso3(iso3cc) {
  	let url = "http://country.io/iso3.json";
  	console.log(iso3cc);
  	debugger;
	const obs$ = ajax(url).pipe(
	  map(data => console.log('data: ', data)),
	  catchError(error => {
	    console.log('error: ', error);
	    return of(error);
	  })
	);
  }

}